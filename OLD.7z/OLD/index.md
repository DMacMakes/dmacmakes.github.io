# The main page


Is it true, can this work?

Will it work if I:
* Use Jekyll?
* And enable the Just-The-Docs theme?

## Jekyll

### What is it?
It's a theme that lets me put h3 under h2 while looking sensible.

## bit Bigging text under header 2

Leading off with fs-5 is great under h2.
{: .fs-5 .fw-300 }

$$ x = y^2 $$ 

### Then more h3 subsections

Here the text is smaller.

### How about a block quote.

According to someone:
> And this isn't.

### And code 
Just some c++.


```cpp
#include <iostream.h>
using namespace std;

const int YOUR_AGE = 455;

int main()
{
  int myAge = 499;
  cout << "It should work." << endl;
}
```


