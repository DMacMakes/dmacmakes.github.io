# dmacmakes.github.io

Will it work if I:
* Use Jekyll?
* And enable the Just-The-Docs theme?

## Jekyll
It's a theme.

```cpp
#include <iostream.h>
using namespace std;

const int YOUR_AGE = 455;

int main()
{
  int myAge = 499;
  cout << "It should work." << endl;
}
```
That was code.
> And this isn't.
